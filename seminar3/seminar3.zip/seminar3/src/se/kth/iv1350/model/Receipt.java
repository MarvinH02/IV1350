package se.kth.iv1350.model;

import se.kth.iv1350.integration.SaleDTO;

import java.time.LocalDate;
/**
 * Receipt makes up for putting att the sale data into one class.
 * The receipt is what is printed out at the end of the program.
 */


    /**
     * Creates an instance of the Receipt class.
     * //   * @param saleDTO SaleDTO object containing information about the sale.
     * // * @param payment Payment object containing information about the payment.
     */
    public class Receipt {
        private int totalVAT;
        private int totalPrice;
        private int totalChange;


        public Receipt(SaleDTO saleDTO, Payment payment) {
            this.totalVAT = totalVAT;
            this.totalPrice = totalPrice;
            this.totalChange = totalChange;
        }

        public int getTotalPrice() {
            return this.totalPrice;
        }

        public int getTotalVAT() {
            return this.totalVAT;
        }

        public int getTotalChange() {
            return this.totalChange;
        }

    /*public String createReceiptString(){
        StringBuilder builder = new StringBuilder();
        appendLine(builder, "New Receipt");
        endSection(builder);

        builder.append("Products: ");
        //appendLine(builder, ItemDTO)
    }*/

        private void appendLine(StringBuilder builder, String line) {
            builder.append(builder);
            builder.append("\n");
        }

        private void endSection(StringBuilder builder) {
            builder.append("\n");
        }
    }
