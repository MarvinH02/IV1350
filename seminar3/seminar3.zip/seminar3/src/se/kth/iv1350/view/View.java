package se.kth.iv1350.view;

import se.kth.iv1350.controller.*;
import se.kth.iv1350.Utility.LogHandler;
import se.kth.iv1350.integration.*;


/**
 * This class represents the View of the program. It handles user input and output to the console.
 */
public class View {
    private Controller contr;



    public View(Controller contr){
        this.contr = contr;
    }



    public void run(){
        contr.StartSale();
        System.out.println("New Sale");

        try {
            contr.scanItem("BB");
            ItemDTO itemDTO1 =  contr.scanItem("BB");
            System.out.println("Name:" + itemDTO1.getItemName() );
            System.out.println("Price:" + itemDTO1.getItemPrice());


            contr.scanItem("BB");
            ItemDTO itemDTO2 = contr.scanItem("AA");
            System.out.println("Name:" + itemDTO2.getItemName() );
            System.out.println("Price:" + itemDTO2.getItemPrice());



            //ItemDTO itemDT02 = contr.scanItem("BB");
           //ItemDTO itemDTO3 = contr.scanItem("CC");

           //System.out.println("Name:" +  itemDTO1.getItemName());
          // System.out.println( "Price:" +  itemDTO1.getItemPrice());

           // System.out.println("Name:" +  itemDT02.getItemName());
            //System.out.println( "Price:" +  itemDT02.getItemPrice());


           // System.out.println("Name:" +  itemDTO3.getItemName());
            //System.out.println( "Price:" +  itemDTO3.getItemPrice());


        }
        catch (ItemNotFoundException exp){
            System.err.println("The item with this identifier is invalid"  );

        }
        catch (NetworkDownException excp){
            System.err.println("The network is down please come back later");

        }



        double total = contr.finalizeTotal();
        double vat = contr.finalizeVAT();

        System.out.println("Total price of sale: " + total + " SEK (VAT: " + vat +  " SEK) | Quantity of items: "
                + contr.getScannedItemCount()  + ".");
        contr.startPayment(1000);

    }
   /* private void callScanItem(String itemID){
        try {


        ItemDTO itemScanned = contr.scanItem(itemID);
        System.out.println(itemScanned.getItemName() + " - price: " + itemScanned.getItemPrice() + " SEK | " + "VAT rate: "
                + itemScanned.getVATRate() + "%");
    }

    */
}
