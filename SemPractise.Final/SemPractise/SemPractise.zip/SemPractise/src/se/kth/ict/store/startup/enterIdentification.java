package se.kth.ict.store.startup;

public class enterIdentification {
}
