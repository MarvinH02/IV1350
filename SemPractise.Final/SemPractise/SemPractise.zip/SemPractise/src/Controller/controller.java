package Controller;

import integration.ExternalAccountingSystem;
import integration.ExternalInventorySystem;
import integration.Printer;
import integration.Sale;


public class Controller {
    private Sale sale;
    private Printer printer;
    private ExternalInventorySystem EISystem;
    private ExternalAccountingSystem EASystem;


    public Controller(Sale sale, Printer printer, ExternalInventorySystem EISystem, ExternalAccountingSystem EAsystem) {
        sale = this.sale;
        printer = this.printer;
        EISystem = this.EISystem;
        EAsystem = this.EASystem;
    }

    public void StartSale() {
    }
    public scanItem(){

    }
}
