package integration;

public class Sale {
}
