package se.kth.iv1350.controller;

import integration.ExternalAccountingSystem;
import integration.ExternalInventorySystem;
import integration.Printer;
import integration.Sale;

public class controller {
        private Sale sale;
        private Printer printer;
        private ExternalAccountingSystem eA;
        private ExternalInventorySystem Ei;


}

