package se.kth.iv1350.integration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ExternalInventorySystemTest {
    private ExternalInventorySystem EI;

    @Before
    public void setUp() {
        EI = new ExternalInventorySystem();
    }


    @After
    public void tearDown() {
        EI = null;
    }


}