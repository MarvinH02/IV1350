package integration;

public class ExternalInventorySystem {
}
