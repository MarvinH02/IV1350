package se.kth.iv1350.integration;

public class NetworkDownException extends Exception {

    public NetworkDownException(String message){
        super(message);
    }
}
