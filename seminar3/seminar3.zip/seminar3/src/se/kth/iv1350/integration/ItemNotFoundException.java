package se.kth.iv1350.integration;

public class ItemNotFoundException extends Exception {

    public ItemNotFoundException (String message){
        super(message);
    }
}
