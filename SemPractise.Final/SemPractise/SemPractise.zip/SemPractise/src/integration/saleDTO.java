package integration;
import java.time.LocalDate;

public class saleDTO {
    PriceTot
}
