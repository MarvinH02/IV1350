package se.kth.iv1350.integration;

import se.kth.iv1350.model.Item;

import java.time.LocalDate;
import java.util.ArrayList;
/**
 * This class represents all the data about a sale, the quantity of items, price etc.
 */

public class SaleDTO {
    private double VATTot;
    private ArrayList<Item> items;
    private double fullPrice;


    public SaleDTO(ArrayList<Item> items, double fullPrice, double VATTot) {
        this.fullPrice = fullPrice;
        this.items = items;
        this.VATTot = VATTot;
    }
}