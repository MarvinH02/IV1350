package se.kth.iv1350.startup;

import se.kth.iv1350.Utility.LogHandler;
import se.kth.iv1350.controller.*;
import se.kth.iv1350.integration.*;
import se.kth.iv1350.view.*;

import java.io.IOException;

public class Main {
    public static void main (String[] args) throws IOException {
        ExternalInventorySystem EI = new ExternalInventorySystem();  
        ExternalAccountingSystem EA = new ExternalAccountingSystem();
        Printer printer = new Printer();
        SaleLog saleLog = new SaleLog();
        LogHandler logHandler = new LogHandler();
        Controller contr = new Controller(saleLog, printer, EI, EA, logHandler);
        View view = new View(contr);
        view.run();
    }

}
