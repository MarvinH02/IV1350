package se.kth.iv1350.integration;
/**
 * This class represents an Item Data Transfer Object (DTO) that contains the necessary
 * information about an item for the sale process.
 */

public class ItemDTO {
    private String itemID;
    private double VATRate;
    private String itemName;
    private double itemPrice;


    public ItemDTO(String itemID, double VATRate, double itemPrice, String itemName) {
        this.itemID = itemID;
        this.VATRate = VATRate;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
    }

    public String getItemID(){
        return this.itemID;
    }

    public double getVATRate(){
        return this.VATRate;
    }

    public String getItemName(){
        return this.itemName;
    }

    public double getItemPrice(){
        return this.itemPrice;
    }
}
