package se.kth.iv1350.model;
import se.kth.iv1350.model.Sale;


public class Payment {

    private double amountPaid;
    private double amountChange;

    public void pay(double amount){
        return;
    }

    public void payment(double amountPaid){
        Sale sale = new Sale();
        double fullPrice = sale.getFullPrice();
        this.amountPaid = amountPaid;
        this.amountChange = amountPaid - fullPrice;
    }
}
