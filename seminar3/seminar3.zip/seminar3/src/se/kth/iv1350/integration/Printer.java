package se.kth.iv1350.integration;

import se.kth.iv1350.model.Receipt;


/**
 * This class will make the receipt at the end of the program.
 */

public class Printer {



        public void printReceipt(Receipt receipt){
            System.out.println("Receipt: ");
        }

    }



