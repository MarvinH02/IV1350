package se.kth.iv1350.controller;

import se.kth.iv1350.Utility.LogHandler;
import se.kth.iv1350.model.*;
import se.kth.iv1350.integration.*;

public class Controller {

    private ExternalAccountingSystem EASystem;

    private ExternalInventorySystem EISystem;

    private Sale sale;

    private Printer printer;

    private SaleLog saleLog;

    private LogHandler logHandler;

    public Controller(SaleLog saleLog, Printer printer, ExternalInventorySystem EISystem, ExternalAccountingSystem EASystem , LogHandler logHandler) {
        this.EASystem = EASystem;
        this.EISystem = EISystem;
        this.printer = printer;
        this.saleLog = saleLog;
        this.logHandler = logHandler;

    }

    public void StartSale() {

        this.sale = new Sale();
    }

    public ItemDTO scanItem(String ItemID) throws ItemNotFoundException, NetworkDownException {


        try {
            ItemDTO itemFound = EISystem.itemFinder(ItemID);
            if (itemFound != null) {
                sale.addItem(itemFound);
                return itemFound;
            }
        } catch (ItemNotFoundException excp) {
            throw excp;

        } catch (NetworkDownException excp) {
            logHandler.LogException(excp);

            throw excp;




        }
        return null;

    }




    public double finalizeTotal() {

        double totalPrice = sale.getFullPrice();
        return totalPrice;
    }
    public double finalizeVAT(){

        double totalVAT = sale.getVATTot();
        return totalVAT;
    }

    public int getScannedItemCount() {

        int itemQuantity = sale.getScannedItemCount();
        return itemQuantity;
    }
    public void startPayment(double amount){
        sale.pay(amount);
        sale.updateTotal();
    }

}
