
package se.kth.iv1350.integration;
import se.kth.iv1350.model.Sale;

import java.util.ArrayList;
import se.kth.iv1350.Utility.LogHandler;
public class ExternalInventorySystem {
    ArrayList<ItemDTO> items = new ArrayList<>();
    public ExternalInventorySystem(){
        items.add(new ItemDTO("AA", 0.10,10,"Apple"));
        items.add(new ItemDTO("BB", 0.12,15,"Bread"));
        items.add(new ItemDTO("CC", 0.15,20,"Orange Juice"));
        items.add(new ItemDTO("DD", 0.12,10,"Milk"));
    }

    public ItemDTO itemFinder(String ItemID) throws ItemNotFoundException, NetworkDownException {


        for (ItemDTO item : items) {
            if (ItemID.equals("NetworkDownIdentifier")) {
                throw new NetworkDownException("The network is down ");
            }
            if (item.getItemID().equals(ItemID)) {
                return item;
            }
        }

        throw new ItemNotFoundException("The item with this identifier " + ItemID + "was not found" );
    }

}
