package Model;
import integration.Sale;
import se.kth.iv1350.controller.controller;

public class model {
    private Sale sale;

}
