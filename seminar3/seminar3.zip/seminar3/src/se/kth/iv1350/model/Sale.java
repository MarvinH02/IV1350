package se.kth.iv1350.model;

import se.kth.iv1350.model.*;
import se.kth.iv1350.integration.*;
import se.kth.iv1350.model.*;


import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Sale is that class that handles all the logic when scanning items and adding items.
 */

public class Sale {
    private double fullPrice;
    private Payment payment;
    private double VATTot;
    private ArrayList<Item> items = new ArrayList<>();

    public void updateTotal(){
        double VATTot = 0;
        double runningTotal = 0;

        for(Item item : items){
            runningTotal += item.getItemPrice() * item.getQuantity();
            VATTot += item.getVAT() * item.getItemPrice() * item.getQuantity();
        }
        this.VATTot = VATTot;
        this.fullPrice = runningTotal + VATTot;
    }
    public SaleDTO addItem(ItemDTO scannedItem){
        boolean itemFound = false;
        for(Item item : items){
            if(item.getItemID().equals(scannedItem.getItemID())) {
                itemFound = true;
                item.incrementItemQuantity();
                break;
            }
        }
        if(!itemFound) {
            Item item = new Item(scannedItem);
            items.add(item);
        }

        updateTotal();

        return new SaleDTO(items, this.fullPrice,this.VATTot);
    }

    public double getFullPrice(){
        return fullPrice;
    }

    public int getScannedItemCount() {
        int itemCount = 1;
        for (Item item : items) {
            if (item.getQuantity() > 1) {
                itemCount += item.getQuantity();
            }

        }
        return itemCount;
    }

    public double getVATTot() {
        return VATTot;
    }
    public void pay(double amount){
        payment = new Payment();
        payment.pay(amount);
    }
}