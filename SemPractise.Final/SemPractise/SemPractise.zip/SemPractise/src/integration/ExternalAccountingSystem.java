package integration;

public class ExternalAccountingSystem {
}
