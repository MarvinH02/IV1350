package se.kth.iv1350.model;

import se.kth.iv1350.integration.ItemDTO;
/**
 * This class represents the item that is scanned.
 */

public class Item {
    private String ItemID;
    private double ItemPrice;
    private int quantity;
    private double VAT;
    private String name;

    public Item (ItemDTO item){
        this.ItemID = item.getItemID();
        this.name = item.getItemName();
        this.VAT = item.getVATRate();
        this.ItemPrice = item.getItemPrice();
        this.quantity = 1;
    }
    public void incrementItemQuantity(){
        quantity += 1;
    }
    public String getItemID() {
        return this.ItemID;
    }

    public String getName(){
        return this.name;
    }

    public double getVAT(){
        return this.VAT;
    }

    public double getItemPrice(){
        return this.ItemPrice;
    }

    public int getQuantity(){
        return this.quantity;
    }
}
