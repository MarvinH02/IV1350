package integration;

public class Printer {
}
