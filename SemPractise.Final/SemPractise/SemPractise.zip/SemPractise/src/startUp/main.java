package startUp;
import Controller.Controller;

public class main {

    public static void main(String[] args) {

        Controller contr = new Controller();


    }

}
